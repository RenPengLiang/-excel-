package com.cjkj.asc.common.excel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 解析结果
 *
 * @author yangrl14628 2019-12-17
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExcelTemplateResult<T> {

    private List<T> items;
    private List<FailReason> failReasons;

    private int getTotalCount() {
        return getFailCount() + getSuccessCount();
    }

    private int getFailCount() {
        return failReasons.size();
    }

    private int getSuccessCount() {
        return items.size();
    }

    public String getFailReason() {
        if (failReasons != null && failReasons.size() > 0) {
            return "数据解析异常, 位置:第" + failReasons.get(0).getLineNumber() + "行" + failReasons.get(0).getReason();
        } else {
            return "";
        }

    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FailReason {
        private int lineNumber;
        private String reason;
        private Exception e;
    }
}
