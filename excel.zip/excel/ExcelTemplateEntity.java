package com.cjkj.asc.common.excel;

import java.lang.annotation.*;

/**
 * @author yangrl14628 2019-12-05
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
@Documented
public @interface ExcelTemplateEntity {

    /** 代码，作为找到模版的 key ，全工程不可重复 */
    String code();

    /** 表名、模版名，中文 */
    String name();
}
