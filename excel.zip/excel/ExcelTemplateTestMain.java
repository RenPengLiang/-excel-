package com.cjkj.asc.common.excel;

import com.cjkj.asc.framework.utils.JsonUtils;
import com.cjkj.asc.standard.IBaseEnum;
import lombok.Data;
import lombok.Getter;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Optional;

import static com.cjkj.asc.common.excel.ExcelTemplateAnnotationParser.parseType;

/**
 * @author yangrl14628 2019-12-23
 */
public class ExcelTemplateTestMain {

    /**
     * 导出demo
     * X 是指具体的导出数据对应的entity类
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        final Optional<ExcelTemplateCore.DataStructureDefinition<X>> o = parseType(X.class);
        final ExcelTemplateCore.DataStructureDefinition<X> object = o.get();
        System.out.println(JsonUtils.toJson(object));

        final X x = object.toDomain(new String[]{
                "123",
                "123123232131231212",
                "OFF",
                "2010-10-10 10:10:10"
        });
        System.out.println(JsonUtils.toJson(x));

//        {
//            final byte[] bytes = ExcelTemplateCore.exportData2003(object, new ArrayList<X>() {{
//                add(x);
//            }});
//            try (var fo = new FileOutputStream("D:/xx1.xls")) {
//                fo.write(bytes);
//            }
//        }
//
//        {
//            final byte[] bytes = ExcelTemplateCore.generateTemplate2003(object);
//            try (var fo = new FileOutputStream("D:/xx2.xls")) {
//                fo.write(bytes);
//            }
//        }

        final ExcelTemplateResult<X> xes = ExcelTemplateCore.resolveData2003(object, new FileInputStream("D:/xx1.xls"));

        System.out.println("解析结果");
        System.out.println(JsonUtils.toJson(xes));
    }

    @Getter
    public enum EnumEnableStatus implements IBaseEnum {
        /** t */
        OFF("OFF", "停用"),
        /** s */
        START("START", "启用");

        private final String code;
        private final String name;

        EnumEnableStatus(String code, final String name) {
            this.code = code;
            this.name = name;
        }
    }

    @Data
    @ExcelTemplateEntity(code = "x", name = "叉")
    public static class X {
        @ExcelTemplateField(name = "数据A", code = "a", sort = 0, required = true)
        private Integer a;
        @ExcelTemplateField(name = "数据B", code = "b", sort = 1, needImport = false)
        private String b;
        @ExcelTemplateField(name = "数据C", code = "c", sort = 2, required = true, info = "这项只能选 1 或 233")
        private Long c;
        @ExcelTemplateField(name = "枚举类型", code = "eee", sort = 3, required = true, info = "是枚举")
        private EnumEnableStatus eee;
        @ExcelTemplateField(name = "审核时间", code = "d", sort = 6, info = "这玩意填不填都行")
        private LocalDateTime d;
        // should not exists
        private String e;
    }
}
