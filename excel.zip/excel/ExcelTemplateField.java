package com.cjkj.asc.common.excel;

import java.lang.annotation.*;

/**
 * excel 模版字段定义
 *
 * @author yangrl14628 2019-12-05
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Documented
public @interface ExcelTemplateField {

    /** 数据索引位置，在模版中用于排序，从0开始，允许不连续，不允许重复 */
    int sort();

    /**
     * 列 code ，用于模版 setter 方法匹配，要与数据库字段的驼峰写法名称保持一致
     */
    String code();

    /**
     * 列中文名，用于导入导出模板的表头称呼
     */
    String name();

    /**
     * 是否必填，如果设置为true，会在生成的模板表头使用红星号标记该字段必填
     */
    boolean required() default false;

    /**
     * 是否是金额，用于字段分和元之间互转，如果设置为true，会在导入数据时将该字段乘100,导出数据时该字段除100
     * 支持int,long,BigDecimal（含装箱类型）,在其他类型的变量上标记不会生效
     */
    boolean isAmount() default false;

    /**
     * 是否作为导入字段，默认为true,一般而言，导出字段集合包含了导入字段集合，加了ExcelTemplateField的变量
     * 均会作为导出和导入字段。故如果该变量不需要导入，只需要赋值为false，默认字段具备已经具备导出属性
     */
    boolean needImport() default true;

    /**
     * 字段说明，用于模板表头的字段说明
     */
    String info() default "";

}
