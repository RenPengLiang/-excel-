package com.cjkj.asc.common.excel;


import com.cjkj.asc.common.utils.ExcelUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static java.util.stream.Collectors.toList;

/**
 * Excel 模版相关工具类，目前仅支持二维表形式的 2003版本的Excel 模版生成与数据导入。
 * <p></p>
 * 依赖{@link ExcelUtils}。
 *
 * @author yangrl14628 2017-11-01
 */
public class ExcelTemplateCore {

    private static final Logger log = LoggerFactory.getLogger(ExcelTemplateCore.class);

    /**
     * 使用两列表头，格式如：
     * <table>
     * <tr><th>姓名</th><th>性别</th></tr>
     * <tr><td>{name}</td><td>{sex}</td></tr>
     * </table>
     * 非两列表头的格式没有第二行：
     * <table>
     * <tr><th>姓名</th><th>性别</th></tr>
     * </table>
     */
    private static final boolean USE_TWO_HEADER = false;

    /**
     * 是否有“填写说明”页
     */
    private static final boolean USE_INTRODUCTION = false;

    // 以上几项不要轻易修改，一旦上线就绝对不能修改

    /**
     * 解析 2003 版本的模版数据
     *
     * @param definition 数据定义
     * @param excelData  Excel 2003 版本的二进制流
     * @param <T>        数据定义中 Domain类的泛型
     * @return 解析结果，逐行的
     * @throws ExcelTemplateException 解析异常
     */
    public static <T> ExcelTemplateResult<T> resolveData2003(final DataStructureDefinition<T> definition, InputStream excelData) {
        final ArrayList<T> domainList = new ArrayList<>();
        final ArrayList<ExcelTemplateResult.FailReason> failReasons = new ArrayList<>();

        try {
            final int num = USE_INTRODUCTION ? 1 : 0;
            ExcelUtils.read2003Excel(excelData, new ExcelUtils.RowBasedConsumer() {
                boolean firstLine = true;

                @Override
                public void consume(int rowIndex, String[] columns) {
                    if (firstLine) {
                        firstLine = false;
                        return;
                    }
                    try {
                        final T resolved = definition.toDomain(columns);
                        domainList.add(resolved);
                    } catch (ExcelTemplateException e) {
                        failReasons.add(new ExcelTemplateResult.FailReason(rowIndex, e.getMessage(), e));
                    }
                }
            }, num, true);
        } catch (Exception e) {
            // 只有最后吞掉异常的地方才允许把异常打印出来
            // LOG.error("解析Excel模版异常！", e);
            throw new ExcelTemplateException("解析Excel模版异常", e);
        }

        return new ExcelTemplateResult<>(domainList, failReasons);
    }

    /**
     * 导出 xls (2003版)。
     *
     * @param definition 数据定义
     * @return excel模版的字节数组
     */
    public static <T> byte[] exportData2003(DataStructureDefinition<T> definition, List<T> objects) {
        // 第一步创建workbook
        HSSFWorkbook wb = new HSSFWorkbook();

        // 创建填写说明
        if (USE_INTRODUCTION) {
            createIntroductionSheet(definition, wb);
        }

        // 创建模版表头
        createTemplateHeaderSheet(definition, wb);

        // 填充数据
        if (objects != null && !objects.isEmpty()) {
            fillData(definition, wb, objects);
        }

        // 生成excel 二进制数据
        final byte[] bytes;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            wb.write(out);
            bytes = out.toByteArray();
        } catch (IOException e) {
            // LOG.error("生成模版失败！{}", e);
            throw new ExcelTemplateException("生成模版失败", e);
        }
        return bytes;
    }

    /**
     * 下载excel模板 xls (2003版)。
     *
     * @param definition 数据定义
     * @return excel模版的字节数组
     */
    public static <T> byte[] generateTemplate2003(DataStructureDefinition<T> definition) {
        // 第一步创建workbook
        HSSFWorkbook wb = new HSSFWorkbook();

        //筛选需要导入的字段, 对每列进行排序和 index 重新组织
        definition.getColumns().sort(Comparator.comparingInt(DataStructureDefinition.ColumnDefinition::getIndex));
        definition.setColumns(definition.getColumns().stream().filter(DataStructureDefinition.ColumnDefinition::needImport).collect(toList()));
        if (definition.getColumns().size() > 0) {
            for (int i = 0; i < definition.getColumns().size(); ++i) {
                final DataStructureDefinition.ColumnDefinition column = definition.getColumns().get(i);
                final int originIndex = column.getIndex();
/*                if (i != originIndex) {
                    log.debug("字段 [{}] 的原始排序为 [{}]，重排后替换成 [{}]", column.getIndex(), originIndex, i);
                }*/
                column.setIndex(i);
            }
        }

        // 创建填写说明
        if (USE_INTRODUCTION) {
            createIntroductionSheet(definition, wb);
        }

        // 创建模版表头
        createTemplateHeaderSheet(definition, wb);

        // 生成excel 二进制数据
        final byte[] bytes;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            wb.write(out);
            bytes = out.toByteArray();
        } catch (IOException e) {
            // LOG.error("生成模版失败！{}", e);
            throw new ExcelTemplateException("生成模版失败", e);
        }
        return bytes;
    }


    /**
     * 工作表模板数据填充
     *
     * @param definition
     * @param wb
     * @param objects
     * @param <T>
     */
    private static <T> void fillData(DataStructureDefinition<T> definition, HSSFWorkbook wb, List<T> objects) {

        // 获取sheet
        final HSSFSheet sheet = wb.getSheet(definition.getName());
        int currentRow = USE_TWO_HEADER ? 2 : 1;
        for (T object : objects) {
            final HSSFRow row = sheet.createRow(currentRow);
            final String[] strings = definition.fromDomain(object);
            for (int i = 0; i < strings.length; i++) {
                HSSFCell cellTemplate = row.createCell(i);
                if (strings[i] != null) {
                    cellTemplate.setCellValue(strings[i]);
                } else {
                    cellTemplate.setCellValue("");
                }

            }
            currentRow++;
        }
    }

    /**
     * 生成“填写说明”工作表
     *
     * @param definition 数据定义
     * @param wb         工作簿
     */
    private static <T> void createIntroductionSheet(
            final DataStructureDefinition<T> definition, final HSSFWorkbook wb) {

        // 创建sheet
        HSSFSheet sheet = wb.createSheet("填写说明");

        int currentRow = 1;
        // “填写说明”表格头
        {
            HSSFRow rowHead = sheet.createRow(currentRow);
            HSSFCell cellHead = rowHead.createCell(1);
            cellHead.setCellValue("填写说明");
            sheet.addMergedRegion(new CellRangeAddress(currentRow, currentRow, 1, 2));

            currentRow++;
        }

        int number = 0;
        // 创建主体内容综述 - 第一行
        {
            HSSFRow rowHead = sheet.createRow(currentRow);
            HSSFCell numCell = rowHead.createCell(1);
            HSSFCell textCell = rowHead.createCell(2);
            numCell.setCellValue(number++);
            textCell.setCellValue("请在第二个工作表填写数据，不要删除第一行，从第二行开始填写。");

            currentRow++;
        }

        // 将需要的列进行宽度调整
        {
            // 需要调整的列index 列表
            final int[] needResize = new int[]{1, 2};
            for (int index : needResize) {
                sheet.autoSizeColumn(index);
                sheet.setColumnWidth(index, (int) (sheet.getColumnWidth(index) * 1.2 + 400));
            }
        }
    }

    /**
     * 创建模版数据工作表，并创建表头
     *
     * @param definition 数据定义
     * @param wb         工作簿
     */
    private static <T> void createTemplateHeaderSheet(
            final DataStructureDefinition<T> definition, final HSSFWorkbook wb) {

        // 创建sheet
        final HSSFSheet sheet = wb.createSheet(definition.getName());
        // 行高
        sheet.setDefaultRowHeight((short) 400);

        // 创建行row:添加表头0行
        final HSSFRow rowHead = sheet.createRow(0);
        final HSSFRow rowTemplate = USE_TWO_HEADER ? sheet.createRow(1) : null;

        // 固定首行
        sheet.createFreezePane(0, 1);

        // 声明垂直居中样式
        final HSSFCellStyle defaultColumnStyle = wb.createCellStyle();
        defaultColumnStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        defaultColumnStyle.setAlignment(HorizontalAlignment.CENTER);

        // 创建单元格
        {
            final HSSFCellStyle style = wb.createCellStyle();
            style.setBorderTop(BorderStyle.THIN);
            style.setBorderBottom(BorderStyle.THIN);
            style.setBorderLeft(BorderStyle.THIN);
            style.setBorderRight(BorderStyle.THIN);
            style.setTopBorderColor(IndexedColors.BLACK.getIndex());
            style.setBottomBorderColor(IndexedColors.BLACK.getIndex());
            style.setLeftBorderColor(IndexedColors.BLACK.getIndex());
            style.setRightBorderColor(IndexedColors.BLACK.getIndex());
            style.setFillForegroundColor(HSSFColor.HSSFColorPredefined.PALE_BLUE.getIndex());
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            final HSSFFont font = wb.createFont();
            font.setColor(IndexedColors.BLACK.getIndex());
            style.setFont(font);
            style.setVerticalAlignment(VerticalAlignment.CENTER);
            style.setAlignment(HorizontalAlignment.CENTER);

            final HSSFCellStyle styleRequired = wb.createCellStyle();
            styleRequired.cloneStyleFrom(style);
            styleRequired.setFillForegroundColor(HSSFColor.HSSFColorPredefined.ROSE.getIndex());

            for (DataStructureDefinition.ColumnDefinition column : definition.getColumns()) {
                final StringBuilder infoBuilder = new StringBuilder();

                final int columnIndex = column.getIndex();

                // 设置第一行（表头）
                final HSSFCell cellHead = rowHead.createCell(columnIndex);
                cellHead.setCellValue(column.getColumnName());
                // 必填项表头格式不同
                if (column.isRequired()) {
                    cellHead.setCellStyle(styleRequired);
                } else {
                    cellHead.setCellStyle(style);
                }

                if (USE_TWO_HEADER) {
                    // 如果是双行头，再生成一列
                    HSSFCell cellTemplate = rowTemplate.createCell(columnIndex);
                    cellTemplate.setCellValue("{" + column.getColumnCode() + "}");
                }

                // 自动设置列宽度
                sheet.autoSizeColumn(columnIndex);
                final int width = sheet.getColumnWidth(columnIndex);
                final int calculatedWidth = (int) (width * 1.2) + 400;
                sheet.setColumnWidth(columnIndex, Math.max(5000, calculatedWidth));

                // 列居中对齐
                sheet.setDefaultColumnStyle(columnIndex, defaultColumnStyle);

                // 设置列取值范围
                final String[] dict = column.getDict();
                if (dict != null && dict.length > 0) {
                    final DataValidationHelper dvHelper = sheet.getDataValidationHelper();
                    final DataValidationConstraint constraint = dvHelper.createExplicitListConstraint(dict);
                    final CellRangeAddressList addressList = new CellRangeAddressList(1, Integer.MAX_VALUE, columnIndex, columnIndex);
                    final DataValidation validation = dvHelper.createValidation(constraint, addressList);
                    validation.setShowErrorBox(true);
                    validation.setSuppressDropDownArrow(true);
                    validation.setSuppressDropDownArrow(false);
                    sheet.addValidationData(validation);
                }

                // 设置注释
                if (column.isRequired()) {
                    infoBuilder.append("必填项。\n");
                }
                infoBuilder.append(column.getInfo());
                if (infoBuilder.length() > 0) {
                    // 前四个参数是坐标点,后四个参数是编辑和显示批注时的大小.
                    final HSSFPatriarch p = sheet.createDrawingPatriarch();
                    final HSSFComment comment = p.createComment(new HSSFClientAnchor(0, 0, 0, 0, (short) 3, 3, (short) 5, 6));
                    // 输入批注信息
                    comment.setString(new HSSFRichTextString(infoBuilder.toString()));
                    // 添加作者
                    comment.setAuthor("template");
                    // 将批注添加到单元格对象中
                    cellHead.setCellComment(comment);
                }
            }
        }
    }

    public enum EnumDataType {
        /**
         * java.lang.String
         **/
        STRING,
        /**
         * java.lang.Integer
         **/
        INTEGER,
        /**
         * java.lang.Long
         **/
        LONG,
        /**
         * java.math.BigDecimal
         **/
        DECIMAL,
        /**
         * java.util.Date
         **/
        DATE
    }

    /**
     * 二维数据结构定义，用于生成模版与方便解析。 本结构不支持嵌套。
     *
     * @param <T> Domain 类型
     */
    public interface DataStructureDefinition<T> {

        /**
         * 数据中文名
         *
         * @return 中文名
         */
        String getName();

        /**
         * 数据英文代码
         *
         * @return 英文代码
         */
        String getCode();

        /**
         * 数据每列定义
         *
         * @return 列定义列表
         */
        List<ColumnDefinition> getColumns();

        /**
         * 设置数据每列定义
         *
         * @return 列定义列表
         */
        void setColumns(List<ColumnDefinition> columnsList);

        /**
         * 转换为Domain类
         *
         * @param columnsData 行数据，按顺序传入该行每列数据，使用String 类型
         * @return Domain类实例
         * @throws RuntimeException 可能抛出各种不明异常，注意Catch
         */
        T toDomain(String[] columnsData);

        /**
         * Domain类转换为String[]
         *
         * @param domain 行数据转化，传入所有行数据，Domain类实例
         * @return String[]行数据
         * @throws RuntimeException 可能抛出各种不明异常，注意Catch
         */
        String[] fromDomain(T domain);

        /**
         * 列定义
         */
        interface ColumnDefinition {
            /**
             * 数据索引位置，从0开始
             *
             * @return 从0开始的数据索引位置
             */
            int getIndex();

            /**
             * 设置索引
             */
            void setIndex(int index);

            // /**
            //  * 获取对应的Java 数据类型
            //  *
            //  * @return 数据类型枚举表示
            //  */
            // EnumDataType getJavaType();

            /**
             * 列Code
             *
             * @return Code
             */
            String getColumnCode();

            /**
             * 列中文名
             *
             * @return 中文名
             */
            String getColumnName();

            /**
             * 字典（取值范围）
             *
             * @return 字典
             */
            String[] getDict();

            /**
             * 字段说明
             *
             * @return 字段说明
             */
            String getInfo();

            /**
             * 是否必填
             *
             * @return 必填
             */
            boolean isRequired();

            /**
             * 是否金额
             *
             * @return
             */
            boolean isAmount();

            /**
             * 是否作为导入字段
             *
             * @return
             */
            boolean needImport();

        }
    }

    /**
     * 各种模版异常
     */
    @SuppressWarnings("serial")
    public static class ExcelTemplateException extends RuntimeException {
        public ExcelTemplateException(String message) {
            super(message);
        }

        public ExcelTemplateException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
