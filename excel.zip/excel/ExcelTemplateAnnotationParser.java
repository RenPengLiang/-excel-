package com.cjkj.asc.common.excel;

import com.cjkj.asc.framework.utils.Money;
import com.cjkj.asc.framework.utils.StringUtils;
import com.cjkj.asc.standard.IBaseEnum;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 解析注解用的
 *
 * @author yangrl14628 2019-12-05
 */
@Slf4j
public class ExcelTemplateAnnotationParser {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * 解析某个类，若没标记 @ExcelTemplateEntity ，则返回 empty ；若标的不对，抛异常
     *
     * @param clazz 类
     * @param <T>   类
     * @return excel 定义
     */
    public static <T> Optional<ExcelTemplateCore.DataStructureDefinition<T>> parseType(Class<T> clazz) {
        try {
            final ExcelTemplateEntity entityAnnotation = clazz.getAnnotation(ExcelTemplateEntity.class);
            if (entityAnnotation != null) {
                // 是 excel 模版标记的实体

                final String templateCode = entityAnnotation.code();
                final String templateName = entityAnnotation.name();
                if (StringUtils.isBlank(templateCode)) {
                    throw new IllegalArgumentException("类 [" + clazz.getName() + "] 注解上的 code 为空");
                }
                if (StringUtils.isBlank(templateName)) {
                    throw new IllegalArgumentException("类 [" + clazz.getName() + "] 注解上的 name 为空");
                }

                // getDeclaredFields 不包含继承来的成员
                final Field[] fields = clazz.getDeclaredFields();
                final ArrayList<TemplateColumnDefinition<T>> columnDefinitions = new ArrayList<>(fields.length);
                final Set<Integer> existsSort = new HashSet<>();
                for (final Field field : fields) {
                    final ExcelTemplateField fieldAnnotation = field.getAnnotation(ExcelTemplateField.class);
                    if (fieldAnnotation != null) {
                        final String columnName = fieldAnnotation.name();
                        final int sort = fieldAnnotation.sort();
                        final String columnCode = fieldAnnotation.code();
                        final Class<?> javaType = field.getType();
                        final boolean required = fieldAnnotation.required();
                        final String[] dict;
                        final String info = fieldAnnotation.info();
                        final boolean isAmount = fieldAnnotation.isAmount();
                        final boolean needImport = fieldAnnotation.needImport();

                        if ("".equals(columnName)) {
                            throw new IllegalArgumentException("类 [" + clazz.getName() + "] 中的字段 [" + columnName + "] 的 name 为空");
                        }
                        if ("".equals(columnCode)) {
                            throw new IllegalArgumentException("类 [" + clazz.getName() + "] 中的字段 [" + columnCode + "] 的 code 为空");
                        }
                        if (existsSort.contains(sort)) {
                            throw new IllegalArgumentException("类 [" + clazz.getName() + "] 中的字段 [" + columnCode + "] 的 sort [" + sort + "] 重复");
                        }
                        existsSort.add(sort);

                        // Detect setter and getter
                        final String setterName = buildSetterName(field);
                        final Method setter = clazz.getMethod(setterName, javaType);
                        final BiConsumer<T, String> setterConsumer = decideSetterConsumer(setter, javaType, fieldAnnotation);
                        final String getterName = buildGetterName(field);
                        final Method getter = clazz.getMethod(getterName);
                        final Function<T, String> getterConsumer = decideGetterConsumer(getter, fieldAnnotation);

                        // 根据枚举生成字典
                        if (javaType.isEnum()) {
                            final Method method;
                            try {
                                method = javaType.getMethod("values");
                            } catch (NoSuchMethodException e) {
                                throw new ExcelTemplateCore.ExcelTemplateException("枚举类型 [" + javaType.getName() + "] 没有 values 方法！！！！");
                            }
                            final IBaseEnum[] values = (IBaseEnum[]) method.invoke(null);

                            dict = Arrays.stream(values).map(IBaseEnum::getName).toArray(String[]::new);
                        } else {
                            dict = new String[]{};
                        }
                        final TemplateColumnDefinition<T> def = new TemplateColumnDefinition<>(sort, columnName,
                                columnCode, dict, required, info, isAmount, needImport, setterConsumer, getterConsumer);
                        columnDefinitions.add(def);
                    }
                }

                // 对每列进行排序和 index 重新组织
                columnDefinitions.sort(Comparator.comparingInt(TemplateColumnDefinition::getIndex));

                for (int i = 0; i < columnDefinitions.size(); i++) {
                    final TemplateColumnDefinition<T> columnDefinition = columnDefinitions.get(i);
                    columnDefinition.setIndex(i);
                }

                final TemplateDataStructure<T> templateDataStructure =
                        new TemplateDataStructure<>(templateName, templateCode, columnDefinitions, clazz);
                return Optional.of(templateDataStructure);
            } else {
                // 没有 ExcelTemplateEntity 标记，忽略
                return Optional.empty();
            }

        } catch (ExcelTemplateCore.ExcelTemplateException e) {
            log.warn("ExcelTemplate 解析异常，抛出原始异常");
            throw e;
        } catch (Exception e) {
            log.warn("ExcelTemplate 解析异常，抛出包装异常");
            throw new ExcelTemplateCore.ExcelTemplateException("ExcelTemplate 解析异常，请确认注解是否正确标注，如 field type 标错", e);
        }
    }

    /**
     * 决定一下 setter 怎么生成
     *
     * @param setter          Method
     * @param javaType        参数类型
     * @param fieldAnnotation 参数注解
     * @param <T>             T
     * @return Setter Lambda
     */
    private static <T> BiConsumer<T, String> decideSetterConsumer(final Method setter, final Class<?> javaType, ExcelTemplateField fieldAnnotation) {
        switch (javaType.getName()) {
            case "java.lang.String":
                return (that, value) -> {
                    try {
                        setter.invoke(that, value);
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("设置 String 值 [" + value + "] 时发生异常", e);
                    }
                };
            case "java.math.BigDecimal":
                return (that, value) -> {
                    try {
                        //标注为金额则需要进行元转分
                        if (fieldAnnotation.isAmount()) {
                            setter.invoke(that, Money.fromFen(value).toFenDecimal());
                        } else {
                            setter.invoke(that, BigDecimal.valueOf(Long.parseLong(value)));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("设置 BigDecimal 值 [" + value + "] 时发生异常", e);
                    }
                };
            case "java.lang.Long":
                return (that, value) -> {
                    try {
                        // 标注为金额则需要进行元转分
                        if (fieldAnnotation.isAmount()) {
                            setter.invoke(that, Money.fromFen(value).toFenLong());
                        } else {
                            setter.invoke(that, Long.parseLong(value));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("值 [" + value + "] 不是有效的长整型数字", e);
                    }
                };
            case "java.lang.Integer":
                return (that, value) -> {
                    try {
                        // 标注为金额则需要进行元转分
                        if (fieldAnnotation.isAmount()) {
                            setter.invoke(that, Money.fromFen(value).toFenInteger());
                        } else {
                            setter.invoke(that, Integer.valueOf(value));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("值 [" + value + "] 不是有效的整型数字", e);
                    }
                };
            case "java.time.LocalDateTime":
                return (that, value) -> {
                    try {
                        if (StringUtils.isNotBlank(value)) {
                            value = value.replace('T', ' ');
                            setter.invoke(that, LocalDateTime.parse(value, DATE_TIME_FORMATTER));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("值 [" + value + "] 不是有效的 yyyy-MM-dd HH:mm:ss 格式时间", e);
                    }
                };
            case "java.time.LocalDate":
                return (that, value) -> {
                    try {
                        if (StringUtils.isNotBlank(value)) {
                            setter.invoke(that, LocalDate.parse(value, DATE_FORMATTER));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("值 [" + value + "] 不是有效的 yyyy-MM-dd 格式日期", e);
                    }
                };
            default:
                if (javaType.isEnum()) {
                    final Method method;
                    try {
                        method = javaType.getMethod("values");
                    } catch (NoSuchMethodException e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("枚举类型 [" + javaType.getName() + "] 没有 values 方法！！！！");
                    }
                    return (that, value) -> {
                        if (StringUtils.isNotBlank(value)) {
                            //set操作，将name转为code
                            try {
                                for (IBaseEnum item : (IBaseEnum[]) method.invoke(null)) {
                                    if (item.getName().equals(value)) {
                                        setter.invoke(that, item);
                                    }
                                }
                            } catch (ClassCastException e) {
                                throw new ExcelTemplateCore.ExcelTemplateException("枚举类型 [" + javaType.getName() + "] 没有实现 IBaseEnum");
                            } catch (Exception e) {
                                throw new ExcelTemplateCore.ExcelTemplateException("类型 [" + javaType.getName() + "] 不支持", e);
                            }
                        }
                    };
                } else {
                    throw new ExcelTemplateCore.ExcelTemplateException("类型 [" + javaType.getName() + "] 不支持");
                }
        }
    }

    /**
     * 决定一下 getter 怎么生成
     *
     * @param getter          Function
     * @param fieldAnnotation 参数注解
     * @return Function<T, String> Lambda
     */
    private static <T> Function<T, String> decideGetterConsumer(final Method getter, ExcelTemplateField fieldAnnotation) {
        final Class<?> javaType = getter.getReturnType();
        switch (javaType.getName()) {
            case "java.lang.String":
                return (domain) -> {
                    try {
                        return (String) getter.invoke(domain);
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("调用 [" + getter.getName() + "] 时发生异常", e);
                    }
                };
            case "java.math.BigDecimal":
            case "java.lang.Integer":
            case "java.lang.Long":
                return (domain) -> {
                    try {
                        // 标注为金额则需要进行分转元
                        if (fieldAnnotation.isAmount()) {
                            return Money.fromFen(String.valueOf(getter.invoke(domain))).toYuanString();
                        } else {
                            return String.valueOf(getter.invoke(domain));
                        }
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("调用 [" + getter.getName() + "] 时发生异常", e);
                    }
                };
            case "java.time.LocalDateTime":
                return (domain) -> {
                    try {
                        final LocalDateTime dt = (LocalDateTime) getter.invoke(domain);
                        return dt == null ? null : dt.format(DATE_TIME_FORMATTER);
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("调用 [" + getter.getName() + "] 时发生异常", e);
                    }
                };
            case "java.time.LocalDate":
                return (domain) -> {
                    try {
                        final LocalDate dt = (LocalDate) getter.invoke(domain);
                        return dt == null ? null : dt.format(DATE_TIME_FORMATTER);
                    } catch (Exception e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("调用 [" + getter.getName() + "] 时发生异常", e);
                    }
                };
            default:
                if (javaType.isEnum()) {
                    final Method method;
                    try {
                        method = javaType.getMethod("values");
                    } catch (NoSuchMethodException e) {
                        throw new ExcelTemplateCore.ExcelTemplateException("枚举类型 [" + javaType.getName() + "] 没有 values 方法！！！！");
                    }
                    return (domain) -> {
                        if (domain != null) {
                            //set操作，将code转为name
                            try {
                                Enum value = (Enum) getter.invoke(domain);
                                if (value == null) {
                                    return null;
                                }
                                for (IBaseEnum item : (IBaseEnum[]) method.invoke(null)) {
                                    if (item.getCode().equals(value.toString())) {
                                        return item.getName();
                                    }
                                }
                            } catch (Exception e) {
                                throw new ExcelTemplateCore.ExcelTemplateException("调用 [" + getter.getName() + "] 时发生异常", e);
                            }
                        }
                        return "";
                    };
                } else {
                    throw new ExcelTemplateCore.ExcelTemplateException("类型 [" + javaType.getName() + "] 不支持");
                }
        }
    }

    /**
     * 找到某个 field 的 getter 方法名
     *
     * @param field 字段
     * @return 名
     */
    private static String buildGetterName(final Field field) {
        final String name = field.getName();
        return "get" + name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    /**
     * 找到某个 field 的 setter 方法名
     *
     * @param field 字段
     * @return 名
     */
    private static String buildSetterName(final Field field) {
        final String name = field.getName();
        return "set" + name.substring(0, 1).toUpperCase() + name.substring(1);
    }

    public static class TemplateColumnDefinition<T> implements ExcelTemplateCore.DataStructureDefinition.ColumnDefinition {

        private int index;
        private String name;
        private String code;
        private String[] dict;
        private boolean required;
        private String info;
        private boolean isAmount;
        private boolean needImport;
        private BiConsumer<T, String> setter;
        private Function<T, String> getter;

        TemplateColumnDefinition(final int index, final String name, final String code,
                String[] dict, boolean required, String info,
                boolean isAmount, boolean needImport,
                final BiConsumer<T, String> setter, Function<T, String> getter) {
            this.index = index;
            this.name = name;
            this.code = code;
            this.dict = dict;
            this.required = required;
            this.info = info;
            this.isAmount = isAmount;
            this.needImport = needImport;
            this.setter = setter;
            this.getter = getter;
        }

        @Override
        public void setIndex(int index) {
            this.index = index;
        }

        @Override
        public int getIndex() {
            return index;
        }

        @Override
        public String getColumnCode() {
            return code;
        }

        @Override
        public String getColumnName() {
            return name;
        }

        @Override
        public String[] getDict() {
            return dict;
        }

        @Override
        public String getInfo() {
            return info;
        }

        @Override
        public boolean isRequired() {
            return required;
        }

        /**
         * 是否金额
         */
        @Override
        public boolean isAmount() {
            return isAmount;
        }

        /**
         * 是否作为导入字段
         */
        @Override
        public boolean needImport() {
            return needImport;
        }
    }

    public static class TemplateDataStructure<T> implements ExcelTemplateCore.DataStructureDefinition<T> {

        private String name;
        private String code;
        private List<TemplateColumnDefinition<T>> columnDefinitions;
        private Class<T> clazz;

        public TemplateDataStructure(final String name, final String code,
                                     final List<TemplateColumnDefinition<T>> columnDefinitions, final Class<T> clazz) {
            this.name = name;
            this.code = code;
            this.columnDefinitions = columnDefinitions;
            this.clazz = clazz;
        }

        @Override
        public String getName() {
            return name;
        }

        @Override
        public String getCode() {
            return code;
        }

        @Override
        public List<ColumnDefinition> getColumns() {
            return columnDefinitions.stream().map(v -> (ColumnDefinition) v).collect(Collectors.toList());
        }

        @Override
        public void setColumns(List<ColumnDefinition> columnsList) {
            columnDefinitions.clear();
            columnDefinitions.addAll(columnsList.stream().map(v -> (TemplateColumnDefinition<T>) v).collect(Collectors.toList()));
        }

        @Override
        public T toDomain(final String[] columnsData) {
            // 统计要导入的字段
            int needImportSize = 0;
            List<TemplateColumnDefinition<T>> needImportList = new ArrayList<>();
            for (TemplateColumnDefinition<T> t : columnDefinitions) {
                if (t.needImport()) {
                    ++needImportSize;
                    needImportList.add(t);
                }
            }
            final int resolveSize = columnsData.length;
            if (needImportSize != resolveSize) {
                log.error("定义尺寸与 excel 解析出来的尺寸不同，可能不是当前模版！定义尺寸：[{}]，解析尺寸：[{}]",
                        needImportSize, resolveSize);
                throw new ExcelTemplateCore.ExcelTemplateException("模版定义尺寸与解析尺寸不符，可能是模版文件错误");
            }

            final T instance;
            try {
                instance = clazz.newInstance();
            } catch (Exception e) {
                throw new ExcelTemplateCore.ExcelTemplateException("解析失败，无法实例化", e);
            }
            // 按顺序逐个
            for (int i = 0; i < needImportList.size(); i++) {
                final TemplateColumnDefinition<T> columnDefinition = needImportList.get(i);
                try {
                    if (columnDefinition.needImport()) {
                        columnDefinition.setter.accept(instance, columnsData[i]);
                    }
                } catch (Exception e) {
                    throw new ExcelTemplateCore.ExcelTemplateException("第" + (i + 1) + "列, 列名:" + needImportList.get(i).name + ", 值:" + columnsData[i] + ", 原因:无法实例化", e);
                }
            }
            return instance;
        }

        /**
         * Domain类转换为String[]
         *
         * @param domain 行数据转化，传入所有行数据，Domain类实例
         * @return String[]行数据
         * @throws RuntimeException 可能抛出各种不明异常，注意Catch
         */
        @Override
        public String[] fromDomain(T domain) {
            final int definitionSize = columnDefinitions.size();
            String[] dataArray = new String[definitionSize];
            // 按顺序逐个
            for (int i = 0; i < definitionSize; i++) {
                final TemplateColumnDefinition<T> columnDefinition = columnDefinitions.get(i);
                dataArray[i] = columnDefinition.getter.apply(domain);
            }
            return dataArray;
        }
    }
}
