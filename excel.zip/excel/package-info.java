/**
 * Excel 模版工具类，支持下载模版、导入、导出。
 * <br /><br />
 * 模版分为两块组件：核心组件和注解组件。
 * <br />
 * 核心组件的功能就是，只要正确地实现了
 * {@link com.cjkj.asc.common.excel.ExcelTemplateCore.DataStructureDefinition}，就可以导入导出数据了；
 * <br />
 * 注解组件就是通过扫描 {@link com.cjkj.asc.common.excel.ExcelTemplateEntity} 和 {@link com.cjkj.asc.common.excel.ExcelTemplateField} ，
 * 来生成 {@link com.cjkj.asc.common.excel.ExcelTemplateCore.DataStructureDefinition} ，实现了注解方式的 Excel 模版定义，加速开发。
 * <br /><br />
 * 后续开发时，必须明确这两层组件的关系，经过分析后，再决定新功能需要加在哪一层。
 *
 * @author yangrl wangqt 2019-12-23
 */
package com.cjkj.asc.common.excel;
