package com.cjkj.asc.common.excel;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 存放一堆定义的存放类，可以根据 code 找出模版
 *
 * @author yangrl14628 2019-12-06
 */
public class ExcelTemplateDefinitionHolder {

    private List<ExcelTemplateCore.DataStructureDefinition<?>> definitions;

    private Map<String, ExcelTemplateCore.DataStructureDefinition<?>> definitionMap;

    public ExcelTemplateDefinitionHolder(List<ExcelTemplateCore.DataStructureDefinition<?>> definitions) {
        this.definitions = definitions;
        definitionMap = this.definitions.stream().collect(Collectors.toMap(ExcelTemplateCore.DataStructureDefinition::getCode, v -> v));
    }

    @SuppressWarnings("unchecked")
    public <T> Optional<ExcelTemplateCore.DataStructureDefinition<T>> get(String entityCode) {
        final ExcelTemplateCore.DataStructureDefinition<T> def =
                (ExcelTemplateCore.DataStructureDefinition<T>) definitionMap.get(entityCode);
        return Optional.ofNullable(def);
    }

    /**
     * 解析模版
     *
     * @param entityCode 模版代码， {@link ExcelTemplateEntity#code()}
     * @param excelData  excel 数据
     * @param <T> 泛型
     * @return 解析结果
     */
    public <T> ExcelTemplateResult<T> resolve(String entityCode, InputStream excelData) {
        final ExcelTemplateCore.DataStructureDefinition<T> def = this.<T>get(entityCode)
                .orElseThrow(() -> new IllegalStateException("找不到模版 " + entityCode));

        return ExcelTemplateCore.resolveData2003(def, excelData);
    }

    /**
     * 解析模版
     *
     * @param entityCode 模版代码， {@link ExcelTemplateEntity#code()}
     * @param excelData  excel 数据
     * @param <T> 泛型
     * @return 解析结果
     */
    public <T> ExcelTemplateResult<T> resolve(String entityCode, byte[] excelData) {
        return this.resolve(entityCode, new ByteArrayInputStream(excelData));
    }

    /**
     * 向里面添加定义
     *
     * @param definition 定义
     * @return code 重复返回 false，否则返回 true
     */
    public boolean addDefinition(ExcelTemplateCore.DataStructureDefinition<?> definition) {
        if (definition == null) {
            throw new NullPointerException("definition is null");
        }
        if (definitionMap.containsKey(definition.getCode())) {
            return false;
        }

        definitions.add(definition);
        definitionMap.put(definition.getCode(), definition);
        return true;
    }
}
